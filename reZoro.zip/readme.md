# reZoro

## A browser extension to undo the rebranding of zoro.to ➡ aniwatch.to
 
The new brand colors and logo clearly are an eyesore. This extension changes some aspects like logo, images and colors of aniwatch.to website to make the site look like the old one. 
